# Visual Architecture — Product Lifecycle

Target: [`/product/industrial-autonomous-assurance`](https://neuralbridge.io/product/industrial-autonomous-assurance)

## lifecycle-hero-end-to-end-assurance

![End-to-end Industrial Autonomous Assurance lifecycle from enrolment through hash-chained ledger to passport and signed head.](../../public/images/visuals/lifecycle-hero-end-to-end-assurance.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** End-to-end Industrial Autonomous Assurance lifecycle from enrolment through hash-chained ledger to passport and signed head.  
**Caption:** Evidence that notices when the machine changed.  
**CLI/API:** `POST /v1/machinery/enrol · assurance machinery passport · assurance attest sign`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-hero-end-to-end-assurance.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-hero-end-to-end-assurance.png" width="1600" height="900" alt="End-to-end Industrial Autonomous Assurance lifecycle from enrolment through hash-chained ledger to passport and signed head." />
</picture>
```

## lifecycle-enrolment-named-person-seals-manifest

![A named person enrols a machine, sealing a baseline configuration manifest and receiving a receipt with the configuration hash.](../../public/images/visuals/lifecycle-enrolment-named-person-seals-manifest.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** A named person enrols a machine, sealing a baseline configuration manifest and receiving a receipt with the configuration hash.  
**Caption:** Enrolment seals the baseline; the receipt carries the configuration hash.  
**CLI/API:** `POST /v1/machinery/enrol`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-enrolment-named-person-seals-manifest.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-enrolment-named-person-seals-manifest.png" width="1600" height="900" alt="A named person enrols a machine, sealing a baseline configuration manifest and receiving a receipt with the configuration hash." />
</picture>
```

## lifecycle-manifest-anatomy-hashes-sources

![Anatomy of a sealed safety software manifest showing items, functions and hash sources (machine, vendor or declared).](../../public/images/visuals/lifecycle-manifest-anatomy-hashes-sources.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** Anatomy of a sealed safety software manifest showing items, functions and hash sources (machine, vendor or declared).  
**Caption:** Each item is marked as read from the machine, supplied by the vendor, or declared.  
**CLI/API:** `POST /v1/machinery/manifest`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-manifest-anatomy-hashes-sources.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-manifest-anatomy-hashes-sources.png" width="1600" height="900" alt="Anatomy of a sealed safety software manifest showing items, functions and hash sources (machine, vendor or declared)." />
</picture>
```

## lifecycle-hash-chained-ledger-append

![Evidence records appended to a per-account hash-chained ledger that can be verified.](../../public/images/visuals/lifecycle-hash-chained-ledger-append.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** Evidence records appended to a per-account hash-chained ledger that can be verified.  
**Caption:** The ledger catches mid-chain edits; only an off-host counter-signature protects the head.  
**CLI/API:** `GET /v1/ledger/verify`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-hash-chained-ledger-append.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-hash-chained-ledger-append.png" width="1600" height="900" alt="Evidence records appended to a per-account hash-chained ledger that can be verified." />
</picture>
```

## lifecycle-drift-detection-machinery-diff

![Configuration drift detection comparing the sealed baseline manifest against the current machine state.](../../public/images/visuals/lifecycle-drift-detection-machinery-diff.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** Configuration drift detection comparing the sealed baseline manifest against the current machine state.  
**Caption:** A differing manifest is a change; silent re-enrolment is refused.  
**CLI/API:** `assurance machinery diff`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-drift-detection-machinery-diff.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-drift-detection-machinery-diff.png" width="1600" height="900" alt="Configuration drift detection comparing the sealed baseline manifest against the current machine state." />
</picture>
```

## lifecycle-change-assurance-case-opened

![A change-assurance case opened from drift, intervention or supplier advisory, owned by a named person.](../../public/images/visuals/lifecycle-change-assurance-case-opened.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** A change-assurance case opened from drift, intervention or supplier advisory, owned by a named person.  
**Caption:** The product records the case; a named person decides to close, reject or defer.  
**CLI/API:** `assurance change assess-drift`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-change-assurance-case-opened.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-change-assurance-case-opened.png" width="1600" height="900" alt="A change-assurance case opened from drift, intervention or supplier advisory, owned by a named person." />
</picture>
```

## lifecycle-verification-against-safety-envelope

![Recorded machine run verified against the declared safety envelope with tiered results.](../../public/images/visuals/lifecycle-verification-against-safety-envelope.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** Recorded machine run verified against the declared safety envelope with tiered results.  
**Caption:** Unchecked is a valid outcome; the product does not invent a pass.  
**CLI/API:** `POST /v1/machine/verify`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-verification-against-safety-envelope.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-verification-against-safety-envelope.png" width="1600" height="900" alt="Recorded machine run verified against the declared safety envelope with tiered results." />
</picture>
```

## lifecycle-coverage-states-current-stale-unchecked

![Coverage states per safety function: current, stale, failing, unchecked, incomplete or never done.](../../public/images/visuals/lifecycle-coverage-states-current-stale-unchecked.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** Coverage states per safety function: current, stale, failing, unchecked, incomplete or never done.  
**Caption:** Coverage answers whether a prior verification still applies after a change.  
**CLI/API:** `assurance machinery coverage`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-coverage-states-current-stale-unchecked.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-coverage-states-current-stale-unchecked.png" width="1600" height="900" alt="Coverage states per safety function: current, stale, failing, unchecked, incomplete or never done." />
</picture>
```

## lifecycle-intervention-recording-dates-inapplicable

![Technician intervention recorded with the software items touched, dating when prior verifications become inapplicable.](../../public/images/visuals/lifecycle-intervention-recording-dates-inapplicable.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** Technician intervention recorded with the software items touched, dating when prior verifications become inapplicable.  
**Caption:** The intervention names what was touched so coverage can be updated.  
**CLI/API:** `assurance machinery record-change`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-intervention-recording-dates-inapplicable.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-intervention-recording-dates-inapplicable.png" width="1600" height="900" alt="Technician intervention recorded with the software items touched, dating when prior verifications become inapplicable." />
</picture>
```

## lifecycle-passport-sealed-evidence-position

![Sealed machine passport that captures the current evidence position for external re-check.](../../public/images/visuals/lifecycle-passport-sealed-evidence-position.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** Sealed machine passport that captures the current evidence position for external re-check.  
**Caption:** A passport is re-checked with assurance machinery check or POST /v1/machinery/passport/check.  
**CLI/API:** `assurance machinery passport`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-passport-sealed-evidence-position.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-passport-sealed-evidence-position.png" width="1600" height="900" alt="Sealed machine passport that captures the current evidence position for external re-check." />
</picture>
```

## lifecycle-signed-ledger-head-attestation

![Signed ledger head that attests the current head of the hash-chained evidence ledger.](../../public/images/visuals/lifecycle-signed-ledger-head-attestation.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** Signed ledger head that attests the current head of the hash-chained evidence ledger.  
**Caption:** The counter-signature protects the head; the chain itself detects mid-ledger edits.  
**CLI/API:** `assurance attest sign`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-signed-ledger-head-attestation.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-signed-ledger-head-attestation.png" width="1600" height="900" alt="Signed ledger head that attests the current head of the hash-chained evidence ledger." />
</picture>
```

## lifecycle-external-verification-no-account

![External verification of a passport or evidence file that requires no account and stores nothing.](../../public/images/visuals/lifecycle-external-verification-no-account.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** External verification of a passport or evidence file that requires no account and stores nothing.  
**Caption:** What can be established from the file alone is stated plainly; what cannot is also stated.  
**CLI/API:** `POST /v1/machinery/passport/check`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-external-verification-no-account.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-external-verification-no-account.png" width="1600" height="900" alt="External verification of a passport or evidence file that requires no account and stores nothing." />
</picture>
```

## lifecycle-artefacts-relationship-diagram

![Relationship diagram of core NeuralBridge artefacts: sealed manifest, receipt, verification bundle, passport, signed ledger head and case export.](../../public/images/visuals/lifecycle-artefacts-relationship-diagram.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** Relationship diagram of core NeuralBridge artefacts: sealed manifest, receipt, verification bundle, passport, signed ledger head and case export.  
**Caption:** Each artefact is re-checkable by anyone who holds the file.  
**CLI/API:** `manifest · receipt · passport · attestation`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-artefacts-relationship-diagram.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-artefacts-relationship-diagram.png" width="1600" height="900" alt="Relationship diagram of core NeuralBridge artefacts: sealed manifest, receipt, verification bundle, passport, signed ledger head and case export." />
</picture>
```

## lifecycle-offline-kit-to-optional-hosted

![Offline enrolment kit that runs locally with a process-level socket guard, with optional later push to a hosted ledger.](../../public/images/visuals/lifecycle-offline-kit-to-optional-hosted.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** Offline enrolment kit that runs locally with a process-level socket guard, with optional later push to a hosted ledger.  
**Caption:** kit and watch never contact a deployment by design.  
**CLI/API:** `python -m assurance kit`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-offline-kit-to-optional-hosted.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-offline-kit-to-optional-hosted.png" width="1600" height="900" alt="Offline enrolment kit that runs locally with a process-level socket guard, with optional later push to a hosted ledger." />
</picture>
```

## lifecycle-full-operator-pipeline

![Full operator pipeline from baseline seal through continuous monitoring, change cases and coverage updates to final attestation.](../../public/images/visuals/lifecycle-full-operator-pipeline.png)

**Route:** `/product/industrial-autonomous-assurance`  
**Alt:** Full operator pipeline from baseline seal through continuous monitoring, change cases and coverage updates to final attestation.  
**Caption:** Continuous evidence that shows which checks still apply after a change.  
**CLI/API:** `assurance watch · assurance change`

```tsx
<picture>
  <source srcSet="/images/visuals/lifecycle-full-operator-pipeline.webp" type="image/webp" />
  <img src="/images/visuals/lifecycle-full-operator-pipeline.png" width="1600" height="900" alt="Full operator pipeline from baseline seal through continuous monitoring, change cases and coverage updates to final attestation." />
</picture>
```

