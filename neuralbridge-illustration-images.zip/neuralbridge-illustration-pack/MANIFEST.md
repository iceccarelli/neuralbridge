# NeuralBridge / Industrial Autonomous Assurance — illustration pack

Photoreal documentary frames for https://neuralbridge.io and https://github.com/iceccarelli/neuralbridge.

Brand: deep navy, white, orange CTAs, square IAA mark. No baked marketing headlines. In-scene labels only (serial plates, firmware stickers, hash strings, route names).

All JPEGs: quality ~90, sRGB, no watermark.

Heroes are 2400×1350 (16:9). Landing heroes also ship a 1600×2000 (4:5) `*-portrait.jpg` crop. Cards/tiles are 1600×1200 (4:3). OG assets are 1200×630.

---

## public/images/hero-hash-chained-cell.jpg

- **Dimensions:** 2400×1350
- **Destination page URL:** https://neuralbridge.io/
- **Destination repo path:** `public/images/hero-hash-chained-cell.jpg` (landing `app/page.tsx` hero)
- **Scene:** Night-shift palletising cell behind a yellow wire fence. An industrial cabinet display shows a short hex hash and timestamp — evidence of what is actually on the machine.
- **Alt:** Night-shift palletising robot cell behind a safety fence with a cabinet display showing a configuration hash and timestamp.

## public/images/hero-hash-chained-cell-portrait.jpg

- **Dimensions:** 1600×2000
- **Destination page URL:** https://neuralbridge.io/ (mobile / 4:5 crop)
- **Destination repo path:** `public/images/hero-hash-chained-cell-portrait.jpg`
- **Scene:** Vertical crop of the same cell: robot stacking cartons, yellow scanner zone on concrete, hash on the local panel.
- **Alt:** Vertical view of a palletising cell at night with a hashed local panel and scanner zone marks.

## public/images/hero-airgap-kit.jpg

- **Dimensions:** 2400×1350
- **Destination page URL:** https://neuralbridge.io/
- **Destination repo path:** `public/images/hero-airgap-kit.jpg` (landing `app/page.tsx` second hero)
- **Scene:** Plant engineer in high-vis at a stainless cabinet. Rugged laptop, capped Ethernet, write-once USB, paper kit checklist. Nothing leaving the room.
- **Alt:** Plant engineer running an air-gapped enrolment kit at an open control cabinet with the network unplugged.

## public/images/hero-airgap-kit-portrait.jpg

- **Dimensions:** 1600×2000
- **Destination page URL:** https://neuralbridge.io/ (mobile / 4:5 crop)
- **Destination repo path:** `public/images/hero-airgap-kit-portrait.jpg`
- **Scene:** Vertical frame of the same air-gap kit: engineer, rugged laptop, unplugged cable, checklist.
- **Alt:** Vertical portrait of a plant engineer with an offline rugged laptop and capped Ethernet at a control cabinet.

## public/images/strip-cra-clock.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/
- **Destination repo path:** `public/images/strip-cra-clock.jpg` (regulation tile, CRA Art. 14)
- **Scene:** Quiet compliance office at dusk. 24-hour clock, early-warning dossier, European industrial building through the window. Serious, not panicked.
- **Alt:** Compliance desk with a 24-hour clock and an Article 14 early-warning dossier overlooking a European plant.

## public/images/strip-machinery-annex.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/
- **Destination repo path:** `public/images/strip-machinery-annex.jpg` (regulation tile, Machinery Reg. 2023/1230)
- **Scene:** Open robot-cell cabinet: safety PLC, firmware sticker ITM-FW 3.8.2, printed inventory of safety-relevant software clipped to the door.
- **Alt:** Open safety cabinet with labelled firmware and a printed inventory of safety-relevant software.

## public/images/strip-hash-chain.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/
- **Destination repo path:** `public/images/strip-hash-chain.jpg` (hash-chained evidence tile)
- **Scene:** Still life of a bound evidence pack, printed hash lines, tamper tape, and a second signature card on the ledger head. Objects, not a chain graphic.
- **Alt:** Bound evidence pack with printed hash lines, tamper-evident tape, and a signature card.

## public/images/strip-offline-kit.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/
- **Destination repo path:** `public/images/strip-offline-kit.jpg` (offline enrolment kit tile)
- **Scene:** Rugged laptop on a plant desk, outbound wall jacks capped, local folder of kit files printed beside it.
- **Alt:** Disconnected rugged laptop on a plant desk with a printed list of local kit files.

## public/images/intent-fleet-advisory.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/
- **Destination repo path:** `public/images/intent-fleet-advisory.jpg` (Start here / IntentModule)
- **Scene:** Overhead of identical palletising lines. One cell under a work light. Clipboard and serial plate AR-7#0412 at Plant 2 / Line 4.
- **Alt:** Overhead of palletising lines with one cell lit and an advisory matched to serial AR-7#0412 on Plant 2 Line 4.

## public/images/playground-validate-placeholder.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/
- **Destination repo path:** `public/images/playground-validate-placeholder.jpg` (ValidatorPlayground gray box)
- **Scene:** Physical Article 14-style draft on a bench with auditor marks on missing fields and a note that Switzerland is not an EU Member State.
- **Alt:** Marked-up Article 14 draft on a bench noting missing fields and that Switzerland is not an EU Member State.

## public/images/card-plan-validator.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/#pricing
- **Destination repo path:** `public/images/card-plan-validator.jpg` (product grid, Validator)
- **Scene:** Clean bench, free validation work: stamp “VERIFIED — NO ACCOUNT”, checklist, no portal.
- **Alt:** Clean bench with a free verification stamp and paper checklist, no account portal.

## public/images/card-plan-register.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/#pricing
- **Destination repo path:** `public/images/card-plan-register.jpg` (product grid, Register €390/mo)
- **Scene:** Manufacturer evidence room: product-family folders and a bound hash-chained register export.
- **Alt:** Manufacturer archive room with product-family folders and a bound hash-chained register.

## public/images/card-plan-cell.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/#pricing
- **Destination repo path:** `public/images/card-plan-cell.jpg` (product grid, Cell €1,290/mo)
- **Scene:** Full palletising cell with a Declaration of Conformity in a fence holder and a configuration plate ITM-FW 3.8.2.
- **Alt:** Palletising cell with a Declaration of Conformity on the fence and a firmware configuration plate.

## public/images/card-engine-machine-safety.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/ (engines grid)
- **Destination repo path:** `public/images/card-engine-machine-safety.jpg`
- **Scene:** Technician outside a marked floor envelope beside a collaborative robot cell. Reduced speed, containment, measured safety — not a crash.
- **Alt:** Technician standing outside marked floor separation tape while a robot cell runs inside its safety envelope.

## public/images/card-engine-annex-iii.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/ (engines grid)
- **Destination repo path:** `public/images/card-engine-annex-iii.jpg`
- **Scene:** HMI listing installed safety software beside an intervention record and an open navy cabinet.
- **Alt:** HMI and paper intervention record showing which safety software is installed and who last changed it.

## public/images/card-engine-fleet.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/ (engines grid)
- **Destination repo path:** `public/images/card-engine-fleet.jpg`
- **Scene:** Row of serial plates; one supplier bulletin matched to plate AR-7#0412 by identity, not a version-range spreadsheet.
- **Alt:** Row of machine serial plates with a supplier bulletin matched to a single serial identity.

## public/images/card-engine-watch.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/ (engines grid)
- **Destination repo path:** `public/images/card-engine-watch.jpg`
- **Scene:** Empty factory at 03:00. One amber panel lamp. Unattended watch. Quiet integrity.
- **Alt:** Empty night factory aisle with a single panel lamp glowing on a distant cabinet.

## public/images/card-engine-attest.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/ (engines grid)
- **Destination repo path:** `public/images/card-engine-attest.jpg`
- **Scene:** Two distinct keys and a ledger-head print with a hash and counter-signature line. The second key is not the operator’s.
- **Alt:** Two different keys beside a signed ledger-head print bearing a hash.

## public/images/card-engine-kit.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/ (engines grid)
- **Destination repo path:** `public/images/card-engine-kit.jpg`
- **Scene:** Printed list of what `kit.json` would open (`report.html`, `evidence.db`, `attestation-request.json`) beside a disconnected laptop.
- **Alt:** Printed kit file list beside a rugged laptop with its Ethernet cable unplugged.

## public/images/card-api-assurance.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/ (product grid / platform)
- **Destination repo path:** `public/images/card-api-assurance.jpg`
- **Scene:** Small plant-adjacent server room. Monitor shows only `GET /v1/plans` and `POST /v1/spec/validate`. FastAPI honesty, not an API galaxy.
- **Alt:** Small server rack beside a terminal showing GET /v1/plans and POST /v1/spec/validate.

## public/images/platform-integration-hub.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/ (platform block)
- **Destination repo path:** `public/images/platform-integration-hub.jpg`
- **Scene:** Ops desk: MCP tool list, two gateways labelled PostgreSQL and REST only, a small FastAPI box. Narrow platform, not universal middleware.
- **Alt:** Ops desk with an MCP tool list, PostgreSQL and REST gateways, and a small FastAPI server.

## public/images/pricing-three-tiers.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/#pricing
- **Destination repo path:** `public/images/pricing-three-tiers.jpg`
- **Scene:** Three physical objects: free validator stamp, monthly register book, sealed cell evidence case.
- **Alt:** Three objects on a bench representing Validator, Register, and Cell plans.

## public/images/solution-manufacturer-hero.jpg

- **Dimensions:** 2400×1350
- **Destination page URL:** https://neuralbridge.io/solutions/manufacturer
- **Destination repo path:** `public/images/solution-manufacturer-hero.jpg` (`app/solutions/manufacturer`)
- **Scene:** Signing day at the palletising cell: CE / Declaration paperwork in the foreground, the running cell behind the fence.
- **Alt:** Manufacturer engineer signing a Declaration of Conformity in front of a running palletising cell.

## public/images/solution-manufacturer-drift.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/solutions/manufacturer
- **Destination repo path:** `public/images/solution-manufacturer-drift.jpg`
- **Scene:** Technician flashing a safety controller; the Declaration binder sits untouched on the shelf behind.
- **Alt:** Engineer updating a safety controller while the Declaration of Conformity binder stays closed on a shelf.

## public/images/solution-manufacturer-fanout.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/solutions/manufacturer
- **Destination repo path:** `public/images/solution-manufacturer-fanout.jpg`
- **Scene:** One supplier advisory laid across a row of serial plates, matched by identity across the fleet.
- **Alt:** A single supplier advisory held against a row of engraved machine serial plates.

## public/images/solution-plant-operator-hero.jpg

- **Dimensions:** 2400×1350
- **Destination page URL:** https://neuralbridge.io/solutions/plant-operator
- **Destination repo path:** `public/images/solution-plant-operator-hero.jpg`
- **Scene:** Night-shift operator at a cell they did not modify. Remote-service laptop already gone; only a coiled cable remains.
- **Alt:** Night-shift operator at a palletising cell after remote service has left, with only a coiled cable on the bench.

## public/images/solution-plant-operator-inspector.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/solutions/plant-operator
- **Destination repo path:** `public/images/solution-plant-operator-inspector.jpg`
- **Scene:** Inspector and operator at the fence. Operator holds a local offline ledger, not an OEM brochure.
- **Alt:** Inspector and plant operator reviewing a local paper ledger at a yellow safety fence.

## public/images/solution-compliance-hero.jpg

- **Dimensions:** 2400×1350
- **Destination page URL:** https://neuralbridge.io/solutions/compliance-officer
- **Destination repo path:** `public/images/solution-compliance-hero.jpg`
- **Scene:** Compliance officer at a night filing desk. Spreadsheet closed. Evidence pack of hashes open. 24-hour clock in frame.
- **Alt:** Compliance officer reviewing a hash evidence pack at night with a 24-hour clock and a closed spreadsheet.

## public/images/solution-compliance-clocks.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/solutions/compliance-officer
- **Destination repo path:** `public/images/solution-compliance-clocks.jpg`
- **Scene:** Two physical clocks and dated stamps: 24-hour early warning and a later report deadline.
- **Alt:** Two clocks and rubber stamps marking a 24-hour early warning and a later report deadline.

## public/images/solution-auditor-hero.jpg

- **Dimensions:** 2400×1350
- **Destination page URL:** https://neuralbridge.io/solutions/insurer-auditor
- **Destination repo path:** `public/images/solution-auditor-hero.jpg`
- **Scene:** Auditor verifying a bundle on their own laptop. No login wall. Hash and signature visible as paper plus screen.
- **Alt:** Independent auditor checking a printed hash list and USB evidence bundle on a personal laptop.

## public/images/solution-auditor-mismatch.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/solutions/insurer-auditor
- **Destination repo path:** `public/images/solution-auditor-mismatch.jpg`
- **Scene:** Nameplate 3.9.0 beside a hash that does not match the file on the maintenance stick.
- **Alt:** Machine nameplate version 3.9.0 next to a maintenance stick whose hash does not match.

## public/images/solution-aiops-hero.jpg

- **Dimensions:** 2400×1350
- **Destination page URL:** https://neuralbridge.io/solutions/ai-ops
- **Destination repo path:** `public/images/solution-aiops-hero.jpg`
- **Scene:** Software team room with MCP tools on one screen and the assurance API routes on another. Real integration layer.
- **Alt:** Two engineers reviewing MCP tools and FastAPI routes GET /v1/plans and POST /v1/spec/validate.

## public/images/solution-aiops-mcp-gateway.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/solutions/ai-ops
- **Destination repo path:** `public/images/solution-aiops-mcp-gateway.jpg`
- **Scene:** Patch panel with only PostgreSQL and REST cables seated; every other port capped. Honest adapter coverage.
- **Alt:** Patch panel with only the PostgreSQL and REST ports cabled and all other ports empty.

## public/images/solution-aiops-dashboard-unwired.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** https://neuralbridge.io/solutions/ai-ops
- **Destination repo path:** `public/images/solution-aiops-dashboard-unwired.jpg`
- **Scene:** A sparse web console on one monitor and a separate assurance-ledger machine beside it. Two systems, not a fake unified product.
- **Alt:** Empty connections console beside a separate assurance ledger box and paper log printer.

## public/images/dashboard/dashboard-empty-connections.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** dashboard empty-state (`src/dashboard`)
- **Destination repo path:** `public/images/dashboard/dashboard-empty-connections.jpg`
- **Scene:** Two dark industrial gateway ports labelled PostgreSQL and REST, dust-capped.
- **Alt:** Empty industrial gateway faceplate labelled PostgreSQL and REST.

## public/images/dashboard/dashboard-audit-trail.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** dashboard audit trail (`src/dashboard`)
- **Destination repo path:** `public/images/dashboard/dashboard-audit-trail.jpg`
- **Scene:** Hybrid paper roll and small terminal showing the same tool-invocation log (`validate_spec`, `list_plans`).
- **Alt:** Paper audit log and a small terminal listing the same tool invocations.

## public/images/dashboard/dashboard-login-plant.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** dashboard splash / login (`src/dashboard`)
- **Destination repo path:** `public/images/dashboard/dashboard-login-plant.jpg`
- **Scene:** Server-room window looking onto a robot cell. Grounded industrial SaaS. Left third darker. No purple gradient.
- **Alt:** View from a dark server-room window onto a palletising robot cell behind a yellow fence.

## public/images/readme-og-hero.jpg

- **Dimensions:** 1200×630
- **Destination page URL:** GitHub README / social preview
- **Destination repo path:** `public/images/readme-og-hero.jpg`
- **Scene:** Same world as the hash-chained cell hero, composed for OG with a darker left third and no baked headline.
- **Alt:** Palletising robot cell at night with space on the left for a social-preview overlay.

## public/og.jpg

- **Dimensions:** 1200×630
- **Destination page URL:** https://neuralbridge.io/ and GitHub social card
- **Destination repo path:** `public/og.jpg`
- **Scene:** Byte-identical copy of `readme-og-hero.jpg`.
- **Alt:** Palletising robot cell at night with space on the left for a social-preview overlay.

## public/images/api-fastapi-docs.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** API docs stand-in (`src/assurance/api`, self-hosted `http://127.0.0.1:8000/docs`)
- **Destination repo path:** `public/images/api-fastapi-docs.jpg`
- **Scene:** Engineer beside a cell holding route notes; rugged laptop lists `GET /v1/plans` and `POST /v1/spec/validate`.
- **Alt:** Engineer reading FastAPI route notes beside a palletising cell.

## public/images/docs-offline-enrolment.jpg

- **Dimensions:** 1600×1200
- **Destination page URL:** docs / `deploy/assurance/KIT.md`
- **Destination repo path:** `public/images/docs-offline-enrolment.jpg`
- **Scene:** Kit running on a plant PC. Outbound cables capped. Local terminal, paper checklist.
- **Alt:** Offline enrolment kit on a plant laptop with outbound Ethernet ports capped.

---

## Drop map

| Site surface | Files |
| --- | --- |
| Landing `app/page.tsx` | `hero-hash-chained-cell.jpg`, `hero-airgap-kit.jpg`, `strip-*.jpg`, `intent-fleet-advisory.jpg`, `playground-validate-placeholder.jpg`, `card-plan-*.jpg`, `card-engine-*.jpg`, `card-api-assurance.jpg`, `platform-integration-hub.jpg`, `pricing-three-tiers.jpg` |
| `app/solutions/manufacturer` | `solution-manufacturer-*` |
| `app/solutions/plant-operator` | `solution-plant-operator-*` |
| `app/solutions/compliance-officer` | `solution-compliance-*` |
| `app/solutions/insurer-auditor` | `solution-auditor-*` |
| `app/solutions/ai-ops` | `solution-aiops-*` |
| GitHub README / social | `public/og.jpg`, `readme-og-hero.jpg` |
| `src/dashboard` | `public/images/dashboard/*` |
| Docs / API | `api-fastapi-docs.jpg`, `docs-offline-enrolment.jpg` |

## Product truth this pack must not contradict

- Product: continuous evidence / assurance for AI-enabled, connected, safety-critical industrial machines.
- Regulations: EU CRA Regulation 2024/2847 Article 14 (24-hour early warning since 11 Sep 2026); Machinery Regulation 2023/1230 Annex III 1.1.9 (from 20 Jan 2027).
- Example machine: Grimaldi/AR-7 palletising cell, Plant 2 Line 4, firmware ITM-FW 3.8.2.
- Plans: Validator (free), Register (€390/mo), Cell (€1,290/mo).
- Engines: machine safety verification, Machinery Annex III, fleet advisory, Watch, Attest, offline enrolment kit.
- Platform: FastAPI + MCP gateway + small adapters (PostgreSQL, REST) + a Next.js dashboard that is not yet wired to assurance.
- API fragments allowed in-scene: `GET /v1/plans`, `POST /v1/spec/validate`.
