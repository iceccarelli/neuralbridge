# Visual Architecture — Applications Page

Target: [`/applications`](https://neuralbridge.io/applications)

All images live at `public/images/visuals/<slug>.png` (master) and `public/images/og/<slug>-og.png` (1200×630).

## applications-hero-five-real-routes

![ Five industrial applications mapped to real NeuralBridge /v1 routes for cobots, packaging, fleet, OEM register and insurer checks. ](../../public/images/visuals/applications-hero-five-real-routes.png)

**Route:** `/applications`  
**Alt:** Five industrial applications mapped to real NeuralBridge /v1 routes for cobots, packaging, fleet, OEM register and insurer checks.  
**Caption:** Applications overview: every card names the exact route it calls and the plan that gates it.  
**CLI/API:** `POST /v1/machine/separation · POST /v1/fleet/advisory · GET /v1/register`

```tsx
<picture>
  <source srcSet="/images/visuals/applications-hero-five-real-routes.webp" type="image/webp" />
  <img src="/images/visuals/applications-hero-five-real-routes.png" width="1600" height="900" alt="Five industrial applications mapped to real NeuralBridge /v1 routes for cobots, packaging, fleet, OEM register and insurer checks." />
</picture>
```

## cobots-iso-ts-15066-separation-envelope

![ ISO/TS 15066 protective separation envelope check for collaborative robot cells on NeuralBridge. ](../../public/images/visuals/cobots-iso-ts-15066-separation-envelope.png)

**Route:** `/applications`  
**Alt:** ISO/TS 15066 protective separation envelope check for collaborative robot cells on NeuralBridge.  
**Caption:** Free separation calculator; recorded-run verification is gated to Cell.  
**CLI/API:** `POST /v1/machine/separation`

```tsx
<picture>
  <source srcSet="/images/visuals/cobots-iso-ts-15066-separation-envelope.webp" type="image/webp" />
  <img src="/images/visuals/cobots-iso-ts-15066-separation-envelope.png" width="1600" height="900" alt="ISO/TS 15066 protective separation envelope check for collaborative robot cells on NeuralBridge." />
</picture>
```

## cobots-free-calc-vs-gated-verify

![ Free ISO/TS 15066 calculator versus Cell-gated machine verification run on NeuralBridge. ](../../public/images/visuals/cobots-free-calc-vs-gated-verify.png)

**Route:** `/applications`  
**Alt:** Free ISO/TS 15066 calculator versus Cell-gated machine verification run on NeuralBridge.  
**Caption:** Calculator is free; verifying a recorded run requires the Cell plan.  
**CLI/API:** `POST /v1/machine/verify`

```tsx
<picture>
  <source srcSet="/images/visuals/cobots-free-calc-vs-gated-verify.webp" type="image/webp" />
  <img src="/images/visuals/cobots-free-calc-vs-gated-verify.png" width="1600" height="900" alt="Free ISO/TS 15066 calculator versus Cell-gated machine verification run on NeuralBridge." />
</picture>
```

## packaging-staleness-join-signoff-vs-change

![ Staleness join showing a prior sign-off dated against a later change on a packaging line. ](../../public/images/visuals/packaging-staleness-join-signoff-vs-change.png)

**Route:** `/applications`  
**Alt:** Staleness join showing a prior sign-off dated against a later change on a packaging line.  
**Caption:** What safety software is on the line and who touched it, dated against the change.  
**CLI/API:** `POST /v1/machinery/coverage`

```tsx
<picture>
  <source srcSet="/images/visuals/packaging-staleness-join-signoff-vs-change.webp" type="image/webp" />
  <img src="/images/visuals/packaging-staleness-join-signoff-vs-change.png" width="1600" height="900" alt="Staleness join showing a prior sign-off dated against a later change on a packaging line." />
</picture>
```

## packaging-safety-software-manifest-coverage

![ Safety software manifest and coverage status for a packaging and palletising line. ](../../public/images/visuals/packaging-safety-software-manifest-coverage.png)

**Route:** `/applications`  
**Alt:** Safety software manifest and coverage status for a packaging and palletising line.  
**Caption:** Manifest lists safety-relevant software items; coverage states per function.  
**CLI/API:** `POST /v1/machinery/manifest`

```tsx
<picture>
  <source srcSet="/images/visuals/packaging-safety-software-manifest-coverage.webp" type="image/webp" />
  <img src="/images/visuals/packaging-safety-software-manifest-coverage.png" width="1600" height="900" alt="Safety software manifest and coverage status for a packaging and palletising line." />
</picture>
```

## fleet-advisory-hash-matched-fanout

![ Supplier advisory fanned out across enrolled machine serials matched by exact hash. ](../../public/images/visuals/fleet-advisory-hash-matched-fanout.png)

**Route:** `/applications`  
**Alt:** Supplier advisory fanned out across enrolled machine serials matched by exact hash.  
**Caption:** One advisory matched by SHA-256, never by version-range arithmetic.  
**CLI/API:** `POST /v1/fleet/advisory`

```tsx
<picture>
  <source srcSet="/images/visuals/fleet-advisory-hash-matched-fanout.webp" type="image/webp" />
  <img src="/images/visuals/fleet-advisory-hash-matched-fanout.png" width="1600" height="900" alt="Supplier advisory fanned out across enrolled machine serials matched by exact hash." />
</picture>
```

## fleet-exact-hash-never-version-range

![ Exact SHA-256 hash matching shown as the only accepted method; version-range arithmetic is rejected. ](../../public/images/visuals/fleet-exact-hash-never-version-range.png)

**Route:** `/applications`  
**Alt:** Exact SHA-256 hash matching shown as the only accepted method; version-range arithmetic is rejected.  
**Caption:** Deterministic by hash; version ranges are never flattened into a boolean.  
**CLI/API:** `POST /v1/fleet/advisory`

```tsx
<picture>
  <source srcSet="/images/visuals/fleet-exact-hash-never-version-range.webp" type="image/webp" />
  <img src="/images/visuals/fleet-exact-hash-never-version-range.png" width="1600" height="900" alt="Exact SHA-256 hash matching shown as the only accepted method; version-range arithmetic is rejected." />
</picture>
```

## oem-article14-register-deadline-clocks

![ OEM Article 14 register showing both 24-hour and 72-hour deadline clocks over a hash-chained ledger. ](../../public/images/visuals/oem-article14-register-deadline-clocks.png)

**Route:** `/applications`  
**Alt:** OEM Article 14 register showing both 24-hour and 72-hour deadline clocks over a hash-chained ledger.  
**Caption:** Both clocks computed correctly; hash-chained ledger with verifiable export.  
**CLI/API:** `GET /v1/register`

```tsx
<picture>
  <source srcSet="/images/visuals/oem-article14-register-deadline-clocks.webp" type="image/webp" />
  <img src="/images/visuals/oem-article14-register-deadline-clocks.png" width="1600" height="900" alt="OEM Article 14 register showing both 24-hour and 72-hour deadline clocks over a hash-chained ledger." />
</picture>
```

## oem-register-verifiable-export-unmetered

![ Verifiable export of the Article 14 register with cases marked as not metered. ](../../public/images/visuals/oem-register-verifiable-export-unmetered.png)

**Route:** `/applications`  
**Alt:** Verifiable export of the Article 14 register with cases marked as not metered.  
**Caption:** Cases are not metered — no per-case cap or charge.  
**CLI/API:** `GET /v1/cases`

```tsx
<picture>
  <source srcSet="/images/visuals/oem-register-verifiable-export-unmetered.webp" type="image/webp" />
  <img src="/images/visuals/oem-register-verifiable-export-unmetered.png" width="1600" height="900" alt="Verifiable export of the Article 14 register with cases marked as not metered." />
</picture>
```

## insurer-always-free-evidence-check

![ Always-free evidence verification path for insurers and auditors; no account required. ](../../public/images/visuals/insurer-always-free-evidence-check.png)

**Route:** `/applications`  
**Alt:** Always-free evidence verification path for insurers and auditors; no account required.  
**Caption:** The buyer or auditor is never the paying customer.  
**CLI/API:** `POST /v1/machine/bundle/check`

```tsx
<picture>
  <source srcSet="/images/visuals/insurer-always-free-evidence-check.webp" type="image/webp" />
  <img src="/images/visuals/insurer-always-free-evidence-check.png" width="1600" height="900" alt="Always-free evidence verification path for insurers and auditors; no account required." />
</picture>
```

## insurer-declaration-bundle-attestation-verify

![ Three free verification paths: Declaration check, bundle re-verification and attestation verify. ](../../public/images/visuals/insurer-declaration-bundle-attestation-verify.png)

**Route:** `/applications`  
**Alt:** Three free verification paths: Declaration check, bundle re-verification and attestation verify.  
**Caption:** What can be established from the file alone, and what cannot.  
**CLI/API:** `POST /v1/ledger/attest/verify`

```tsx
<picture>
  <source srcSet="/images/visuals/insurer-declaration-bundle-attestation-verify.webp" type="image/webp" />
  <img src="/images/visuals/insurer-declaration-bundle-attestation-verify.png" width="1600" height="900" alt="Three free verification paths: Declaration check, bundle re-verification and attestation verify." />
</picture>
```

## applications-route-to-plan-gating-matrix

![ Matrix mapping the five applications to their exact /v1 routes and the plan that gates each. ](../../public/images/visuals/applications-route-to-plan-gating-matrix.png)

**Route:** `/applications`  
**Alt:** Matrix mapping the five applications to their exact /v1 routes and the plan that gates each.  
**Caption:** Every row is gated in code; if it is not gated, it is free.  
**CLI/API:** `openapi.json`

```tsx
<picture>
  <source srcSet="/images/visuals/applications-route-to-plan-gating-matrix.webp" type="image/webp" />
  <img src="/images/visuals/applications-route-to-plan-gating-matrix.png" width="1600" height="900" alt="Matrix mapping the five applications to their exact /v1 routes and the plan that gates each." />
</picture>
```

## applications-cli-local-to-optional-hosted

![ Offline-first CLI that can later call a hosted deployment; kit and watch never leave the machine. ](../../public/images/visuals/applications-cli-local-to-optional-hosted.png)

**Route:** `/applications`  
**Alt:** Offline-first CLI that can later call a hosted deployment; kit and watch never leave the machine.  
**Caption:** Same code the hosted API calls, runnable on your own machine first.  
**CLI/API:** `python -m assurance`

```tsx
<picture>
  <source srcSet="/images/visuals/applications-cli-local-to-optional-hosted.webp" type="image/webp" />
  <img src="/images/visuals/applications-cli-local-to-optional-hosted.png" width="1600" height="900" alt="Offline-first CLI that can later call a hosted deployment; kit and watch never leave the machine." />
</picture>
```

## applications-change-assurance-case-lifecycle

![ Change-assurance case lifecycle from drift detection through human decision gate to close, reject or defer. ](../../public/images/visuals/applications-change-assurance-case-lifecycle.png)

**Route:** `/applications`  
**Alt:** Change-assurance case lifecycle from drift detection through human decision gate to close, reject or defer.  
**Caption:** A named person owns the case; the product never decides.  
**CLI/API:** `assurance change assess-drift`

```tsx
<picture>
  <source srcSet="/images/visuals/applications-change-assurance-case-lifecycle.webp" type="image/webp" />
  <img src="/images/visuals/applications-change-assurance-case-lifecycle.png" width="1600" height="900" alt="Change-assurance case lifecycle from drift detection through human decision gate to close, reject or defer." />
</picture>
```

## applications-workspace-investigate-one-place

![ Single workspace view of one enrolled machine showing configuration hash, evidence timeline and intervention history. ](../../public/images/visuals/applications-workspace-investigate-one-place.png)

**Route:** `/applications`  
**Alt:** Single workspace view of one enrolled machine showing configuration hash, evidence timeline and intervention history.  
**Caption:** Configuration, evidence and intervention history in one place.  
**CLI/API:** `GET /v1/investigate`

```tsx
<picture>
  <source srcSet="/images/visuals/applications-workspace-investigate-one-place.webp" type="image/webp" />
  <img src="/images/visuals/applications-workspace-investigate-one-place.png" width="1600" height="900" alt="Single workspace view of one enrolled machine showing configuration hash, evidence timeline and intervention history." />
</picture>
```

