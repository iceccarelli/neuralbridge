# NeuralBridge / Industrial Autonomous Assurance — illustration pack

Photoreal documentary stills for the live product at [https://neuralbridge.io](https://neuralbridge.io) and the repo [https://github.com/iceccarelli/neuralbridge](https://github.com/iceccarelli/neuralbridge).

Drop `public/` onto the marketing app and dashboard as noted below. JPEGs are sRGB, quality ~90, no watermarks, no typeset marketing headlines.

Product truth these frames are built for:

- Continuous evidence / assurance for AI-enabled, connected, safety-critical industrial machines.
- Regulations: EU CRA Regulation 2024/2847 Article 14 (24-hour early warning since 11 Sep 2026) and Machinery Regulation 2023/1230 Annex III 1.1.9 (from 20 Jan 2027).
- Example machine: Grimaldi/AR-7 palletising cell, Plant 2 Line 4, firmware ITM-FW 3.8.2.
- Plans: Validator (free), Register (€390/mo), Cell (€1,290/mo).
- Engines: machine safety verification, Machinery Annex III, fleet advisory, Watch, Attest, offline enrolment kit.
- Platform: FastAPI + MCP gateway + PostgreSQL and REST adapters + a Next.js dashboard that is **not** yet wired to assurance.

---

## public/images/hero-hash-chained-cell.jpg

- **Dimensions:** 2400×1350 (16:9)
- **Destination page:** https://neuralbridge.io/ (`app/page.tsx` landing hero)
- **Destination repo path:** `public/images/hero-hash-chained-cell.jpg`
- **Scene:** Night-shift palletising cell behind a wire safety fence. An industrial panel shows a short hex hash and a timestamp; yellow scanner marks sit on polished concrete.
- **Alt:** Night view of a fenced palletising robot cell with a cabinet display showing a machine hash and timestamp.

## public/images/hero-airgap-kit.jpg

- **Dimensions:** 2400×1350 (16:9)
- **Destination page:** https://neuralbridge.io/ (`app/page.tsx` secondary hero)
- **Destination repo path:** `public/images/hero-airgap-kit.jpg`
- **Scene:** Plant engineer in a high-vis vest at an open stainless cabinet. Rugged laptop, capped Ethernet, write-once USB stick, and a paper kit checklist. Nothing leaving the room.
- **Alt:** Engineer running an air-gapped enrolment kit at a factory control cabinet with network ports capped.

## public/images/strip-cra-clock.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (CRA / Article 14 regulation tile)
- **Destination repo path:** `public/images/strip-cra-clock.jpg`
- **Scene:** Quiet compliance office at dusk. A 24-hour wall clock, an early-warning dossier, and a European industrial building through the window. Serious, not panicked.
- **Alt:** Compliance officer reviewing an early-warning dossier under a 24-hour clock.

## public/images/strip-machinery-annex.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (Machinery Regulation tile)
- **Destination repo path:** `public/images/strip-machinery-annex.jpg`
- **Scene:** Open robot-cell cabinet: safety PLC modules, an ITM-FW 3.8.2 sticker, and a printed inventory of safety-relevant software clipped to the door.
- **Alt:** Open safety cabinet showing labelled PLC modules and a printed safety-software inventory.

## public/images/strip-hash-chain.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (hash-chain / ledger tile)
- **Destination repo path:** `public/images/strip-hash-chain.jpg`
- **Scene:** Bound evidence pack printed with hash lines, tamper tape, and a second signature card on the ledger head. Physical objects, not a chain graphic.
- **Alt:** Bound paper evidence pack sealed with tamper tape and a counter-signature card.

## public/images/strip-offline-kit.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (offline kit tile)
- **Destination repo path:** `public/images/strip-offline-kit.jpg`
- **Scene:** Rugged laptop on a plant desk showing a local kit folder. Outbound ports unused. Airplane-mode energy.
- **Alt:** Rugged plant laptop showing local kit files with network ports unused.

## public/images/intent-fleet-advisory.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (Start here / IntentModule)
- **Destination repo path:** `public/images/intent-fleet-advisory.jpg`
- **Scene:** Overhead of identical palletising lines. Plant 2 Line 4 is under a work light. A clipboard advisory sits on the cabinet stamped AR-7#0412.
- **Alt:** Factory hall of palletising cells with a supplier advisory clipped to Plant 2 Line 4.

## public/images/playground-validate-placeholder.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (gray box beside ValidatorPlayground)
- **Destination repo path:** `public/images/playground-validate-placeholder.jpg`
- **Scene:** Physical Article 14 draft on a bench with auditor marks, missing fields, and a handwritten note that Switzerland is not an EU Member State.
- **Alt:** Marked-up Article 14 early-warning form noting Switzerland is not an EU Member State.

## public/images/card-plan-validator.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (product grid — Validator)
- **Destination repo path:** `public/images/card-plan-validator.jpg`
- **Scene:** Clean inspection bench, verification record, and a FREE stamp. No account portal.
- **Alt:** Verification record stamped FREE on a navy inspection bench.

## public/images/card-plan-register.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (product grid — Register)
- **Destination repo path:** `public/images/card-plan-register.jpg`
- **Scene:** Manufacturer evidence room: product-family archive boxes and a bound evidence register on the table.
- **Alt:** Archive room of product-family boxes with an open evidence register.

## public/images/card-plan-cell.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (product grid — Cell)
- **Destination repo path:** `public/images/card-plan-cell.jpg`
- **Scene:** Full palletising cell behind a fence. Declaration of Conformity in a holder and an AR-7 configuration plate.
- **Alt:** Robot cell fence holding a Declaration of Conformity and an AR-7 configuration plate.

## public/images/card-engine-machine-safety.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (engine tile — machine safety)
- **Destination repo path:** `public/images/card-engine-machine-safety.jpg`
- **Scene:** Collaborative robot and technician outside yellow floor-separation marks. Reduced speed, measured envelope, not a crash.
- **Alt:** Technician standing outside marked collaborative workspace around a robot arm.

## public/images/card-engine-annex-iii.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (engine tile — Annex III)
- **Destination repo path:** `public/images/card-engine-annex-iii.jpg`
- **Scene:** HMI listing installed safety software and last-changed time, cabinet open, paper intervention record, ITM-FW 3.8.2 label.
- **Alt:** Safety HMI and intervention record on an open electrical cabinet.

## public/images/card-engine-fleet.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (engine tile — fleet advisory)
- **Destination repo path:** `public/images/card-engine-fleet.jpg`
- **Scene:** Row of identical cabinets. One serial plate AR-7#0412 has a single supplier bulletin matched to that identity.
- **Alt:** Supplier bulletin clipped under serial plate AR-7#0412 on a row of identical machines.

## public/images/card-engine-watch.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (engine tile — Watch)
- **Destination repo path:** `public/images/card-engine-watch.jpg`
- **Scene:** Empty factory at night. One amber panel lamp. Unattended watch, quiet integrity.
- **Alt:** Empty night factory with a single amber cabinet lamp glowing at the far end.

## public/images/card-engine-attest.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (engine tile — Attest)
- **Destination repo path:** `public/images/card-engine-attest.jpg`
- **Scene:** Two distinct keys tagged OPERATOR and ATTEST beside a ledger-head print with a blank counter-signature line.
- **Alt:** Operator and attest keys beside a printed ledger head awaiting a counter-signature.

## public/images/card-engine-kit.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (engine tile — offline kit)
- **Destination repo path:** `public/images/card-engine-kit.jpg`
- **Scene:** Printed kit file list of paths a run would open. Closed rugged laptop, port cap on the desk. Touches-nothing energy.
- **Alt:** Printed kit file list next to a disconnected rugged laptop and a port cap.

## public/images/card-api-assurance.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (product grid — assurance API)
- **Destination repo path:** `public/images/card-api-assurance.jpg`
- **Scene:** Small plant-adjacent server closet. Monitor shows only `GET /v1/plans` and `POST /v1/spec/validate`. One amber rack LED.
- **Alt:** Plant server closet monitor listing GET /v1/plans and POST /v1/spec/validate.

## public/images/platform-integration-hub.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/ (platform block)
- **Destination repo path:** `public/images/platform-integration-hub.jpg`
- **Scene:** Ops desk with an MCP tool list, two gateways labelled PostgreSQL and REST only, and a small FastAPI server. Narrow platform, not a mesh.
- **Alt:** Desk with PostgreSQL and REST gateway boxes beside a FastAPI server and MCP tool list.

## public/images/pricing-three-tiers.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/#pricing
- **Destination repo path:** `public/images/pricing-three-tiers.jpg`
- **Scene:** Three objects on a navy bench: FREE stamp (Validator), monthly REGISTER book, sealed CELL evidence case.
- **Alt:** Free validator stamp, monthly register book, and sealed cell evidence case on a bench.

## public/images/solution-manufacturer-hero.jpg

- **Dimensions:** 2400×1350 (16:9)
- **Destination page:** https://neuralbridge.io/solutions/manufacturer (`app/solutions/[slug]/page.tsx`)
- **Destination repo path:** `public/images/solution-manufacturer-hero.jpg`
- **Scene:** Signing-day palletising cell. CE / Declaration paperwork in the foreground; the live cell and a firmware plate behind the fence.
- **Alt:** Declaration of Conformity being signed in front of a live palletising cell.

## public/images/solution-manufacturer-drift.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/solutions/manufacturer
- **Destination repo path:** `public/images/solution-manufacturer-drift.jpg`
- **Scene:** Technician flashing a safety controller. Declaration binder untouched on the shelf behind them.
- **Alt:** Technician updating a safety controller while the Declaration binder stays closed on a shelf.

## public/images/solution-manufacturer-fanout.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/solutions/manufacturer
- **Destination repo path:** `public/images/solution-manufacturer-fanout.jpg`
- **Scene:** One supplier advisory held over a table of many serial plates. Fan-out by identity, not a version-range spreadsheet.
- **Alt:** Hand holding one supplier advisory above rows of metal serial plates.

## public/images/solution-plant-operator-hero.jpg

- **Dimensions:** 2400×1350 (16:9)
- **Destination page:** https://neuralbridge.io/solutions/plant-operator
- **Destination repo path:** `public/images/solution-plant-operator-hero.jpg`
- **Scene:** Night-shift operator at a cell she did not modify. Remote-service laptop already gone; empty stool remains.
- **Alt:** Night-shift operator standing at a fenced cell after remote service has left.

## public/images/solution-plant-operator-inspector.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/solutions/plant-operator
- **Destination repo path:** `public/images/solution-plant-operator-inspector.jpg`
- **Scene:** Inspector and operator at the fence. Operator holds a local offline ledger with tamper tape, not an OEM brochure.
- **Alt:** Operator showing an inspector a local offline ledger at a robot cell fence.

## public/images/solution-compliance-hero.jpg

- **Dimensions:** 2400×1350 (16:9)
- **Destination page:** https://neuralbridge.io/solutions/compliance-officer
- **Destination repo path:** `public/images/solution-compliance-hero.jpg`
- **Scene:** Compliance officer at a night filing desk. Spreadsheet closed, evidence pack open, 24-hour clock in frame.
- **Alt:** Compliance officer reviewing an evidence pack at night with a wall clock behind her.

## public/images/solution-compliance-clocks.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/solutions/compliance-officer
- **Destination repo path:** `public/images/solution-compliance-clocks.jpg`
- **Scene:** Two physical clocks and stamps: EARLY WARNING on a 24-hour face, REPORT DEADLINE with a later dated card.
- **Alt:** Two analog clocks with early-warning and report-deadline stamps.

## public/images/solution-auditor-hero.jpg

- **Dimensions:** 2400×1350 (16:9)
- **Destination page:** https://neuralbridge.io/solutions/insurer-auditor
- **Destination repo path:** `public/images/solution-auditor-hero.jpg`
- **Scene:** Auditor verifying a bundle on his own laptop. No login wall. Hash list and signature visible as paper plus screen.
- **Alt:** Auditor comparing on-screen hashes with a signed paper evidence list.

## public/images/solution-auditor-mismatch.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/solutions/insurer-auditor
- **Destination repo path:** `public/images/solution-auditor-mismatch.jpg`
- **Scene:** Nameplate 3.9.0 beside two different SHA-256 strings — paper file hash versus the tag on the maintenance stick.
- **Alt:** Version plate 3.9.0 next to mismatched hashes on paper and a USB stick tag.

## public/images/solution-aiops-hero.jpg

- **Dimensions:** 2400×1350 (16:9)
- **Destination page:** https://neuralbridge.io/solutions/ai-ops
- **Destination repo path:** `public/images/solution-aiops-hero.jpg`
- **Scene:** Software team room. One screen lists MCP tools; the other lists FastAPI routes including GET /v1/plans. Integration layer, not a demo booth.
- **Alt:** Two engineers reviewing MCP tools and FastAPI plan routes on side-by-side monitors.

## public/images/solution-aiops-mcp-gateway.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/solutions/ai-ops
- **Destination repo path:** `public/images/solution-aiops-mcp-gateway.jpg`
- **Scene:** Patch panel with only PostgreSQL and REST cables seated. Other ports empty. Honest adapter coverage.
- **Alt:** Rack patch panel with only the PostgreSQL and REST ports cabled.

## public/images/solution-aiops-dashboard-unwired.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** https://neuralbridge.io/solutions/ai-ops
- **Destination repo path:** `public/images/solution-aiops-dashboard-unwired.jpg`
- **Scene:** Sparse web console on one monitor and a separate ledger-style industrial PC beside it. Two systems, not a unified product shot.
- **Alt:** Empty web console next to a separate industrial PC with a paper production log.

## public/images/readme-og-hero.jpg

- **Dimensions:** 1200×630
- **Destination page:** GitHub README / social preview
- **Destination repo path:** `public/images/readme-og-hero.jpg`
- **Scene:** Same world as the hash-chained cell hero, composed with a darker empty left third for optional future text. No headline baked in.
- **Alt:** Night palletising cell behind a safety fence with a dark open left side.

## public/images/api-fastapi-docs.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** API / docs stand-in for unhosted `/docs` (`src/assurance/api`, http://127.0.0.1:8000/docs when self-hosted)
- **Destination repo path:** `public/images/api-fastapi-docs.jpg`
- **Scene:** Engineer beside a cell reading a printed route sheet: GET /v1/plans and POST /v1/spec/validate. Laptop shows a plain FastAPI route list.
- **Alt:** Engineer holding a printed FastAPI route list in front of a robot cell.

## public/images/docs-offline-enrolment.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** KIT.md / docs (`deploy/assurance/KIT.md`)
- **Destination repo path:** `public/images/docs-offline-enrolment.jpg`
- **Scene:** Kit running on a rugged plant PC. Outbound cables capped in red. Write-once stick inserted. Local file-check terminal only.
- **Alt:** Rugged plant PC running a local enrolment kit check with outbound ports capped.

## public/images/dashboard/dashboard-empty-connections.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** dashboard empty-state (`src/dashboard`)
- **Destination repo path:** `public/images/dashboard/dashboard-empty-connections.jpg`
- **Scene:** Two dark unused industrial ports labelled PostgreSQL and REST.
- **Alt:** Empty industrial ports labelled PostgreSQL and REST.

## public/images/dashboard/dashboard-audit-trail.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** dashboard audit view (`src/dashboard`)
- **Destination repo path:** `public/images/dashboard/dashboard-audit-trail.jpg`
- **Scene:** Hybrid paper-and-screen audit log of tool invocations with timestamps and short hashes.
- **Alt:** Paper audit log placed beside a tablet showing the same tool-invocation hashes.

## public/images/dashboard/dashboard-login-plant.jpg

- **Dimensions:** 1600×1200 (4:3)
- **Destination page:** dashboard splash / login (`src/dashboard`)
- **Destination repo path:** `public/images/dashboard/dashboard-login-plant.jpg`
- **Scene:** Server-room window looking onto a palletising cell. Dark kiosk in the foreground. Grounded industrial SaaS, no purple gradient.
- **Alt:** Dark server room looking through a window onto a robot palletising cell.

## public/og.jpg

- **Dimensions:** 1200×630
- **Destination page:** GitHub / social Open Graph (copy of readme-og-hero.jpg)
- **Destination repo path:** `public/og.jpg`
- **Scene:** Same frame as `readme-og-hero.jpg`.
- **Alt:** Night palletising cell behind a safety fence with a dark open left side.

---

## Suggested wiring (repo)

| Surface | Files |
|---|---|
| `app/page.tsx` landing | heroes, `strip-*`, `intent-fleet-advisory`, `playground-validate-placeholder`, `card-plan-*`, `card-engine-*`, `card-api-assurance`, `platform-integration-hub`, `pricing-three-tiers` |
| `app/solutions/manufacturer` | `solution-manufacturer-*` |
| `app/solutions/plant-operator` | `solution-plant-operator-*` |
| `app/solutions/compliance-officer` | `solution-compliance-*` |
| `app/solutions/insurer-auditor` | `solution-auditor-*` |
| `app/solutions/ai-ops` | `solution-aiops-*` |
| GitHub README / social | `public/og.jpg`, `public/images/readme-og-hero.jpg` |
| `src/dashboard` | `public/images/dashboard/*` |
| Docs / API | `api-fastapi-docs.jpg`, `docs-offline-enrolment.jpg` |

Verification remains free at every tier. The dashboard is not depicted as already wired to the assurance ledger.
