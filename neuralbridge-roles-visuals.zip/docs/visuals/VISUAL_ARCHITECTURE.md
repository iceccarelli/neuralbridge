# NeuralBridge Role Pages Visual Architecture

Light premium visuals for the six solution / role pages.

### 01. manufacturer-declaration-of-conformity-evidence-gap
![Light premium NeuralBridge role visual: manufacturer declaration of conformity evidence gap](../../public/images/visuals/manufacturer-declaration-of-conformity-evidence-gap.png)

### 02. system-integrator-verifiable-evidence-chain
![Light premium NeuralBridge role visual: system integrator verifiable evidence chain](../../public/images/visuals/system-integrator-verifiable-evidence-chain.png)

### 03. plant-operator-air-gapped-workstation
![Light premium NeuralBridge role visual: plant operator air gapped workstation](../../public/images/visuals/plant-operator-air-gapped-workstation.png)

### 04. compliance-officer-cra-article-14-dual-clocks
![Light premium NeuralBridge role visual: compliance officer cra article 14 dual clocks](../../public/images/visuals/compliance-officer-cra-article-14-dual-clocks.png)

### 05. insurer-auditor-zero-account-verification
![Light premium NeuralBridge role visual: insurer auditor zero account verification](../../public/images/visuals/insurer-auditor-zero-account-verification.png)

### 06. ai-ops-mcp-gateway-human-approval
![Light premium NeuralBridge role visual: ai ops mcp gateway human approval](../../public/images/visuals/ai-ops-mcp-gateway-human-approval.png)

### 07. six-roles-overview
![Light premium NeuralBridge role visual: six roles overview](../../public/images/visuals/six-roles-overview.png)

### 08. change-assurance-case-human-gate
![Light premium NeuralBridge role visual: change assurance case human gate](../../public/images/visuals/change-assurance-case-human-gate.png)

### 09. iso15066-coverage-for-operators-manufacturers
![Light premium NeuralBridge role visual: iso15066 coverage for operators manufacturers](../../public/images/visuals/iso15066-coverage-for-operators-manufacturers.png)

### 10. fleet-advisory-deterministic-fanout
![Light premium NeuralBridge role visual: fleet advisory deterministic fanout](../../public/images/visuals/fleet-advisory-deterministic-fanout.png)

### 11. offline-enrolment-kit-for-plant
![Light premium NeuralBridge role visual: offline enrolment kit for plant](../../public/images/visuals/offline-enrolment-kit-for-plant.png)

### 12. always-free-verify-for-insurers-auditors
![Light premium NeuralBridge role visual: always free verify for insurers auditors](../../public/images/visuals/always-free-verify-for-insurers-auditors.png)

### 13. pricing-tiers-aligned-to-roles
![Light premium NeuralBridge role visual: pricing tiers aligned to roles](../../public/images/visuals/pricing-tiers-aligned-to-roles.png)

### 14. hash-chained-ledger-anatomy-all-roles
![Light premium NeuralBridge role visual: hash chained ledger anatomy all roles](../../public/images/visuals/hash-chained-ledger-anatomy-all-roles.png)

### 15. role-to-capability-mapping
![Light premium NeuralBridge role visual: role to capability mapping](../../public/images/visuals/role-to-capability-mapping.png)
